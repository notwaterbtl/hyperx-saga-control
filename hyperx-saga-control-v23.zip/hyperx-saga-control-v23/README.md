# HyperX Saga Control

A Fedora/KDE tray application for the **HyperX Pulsefire Saga Pro** mouse.

This is a userspace Linux control app built from the reverse engineering done in this conversation. It does not require a kernel module.

## Current features

- Runs in the KDE Plasma system tray.
- Auto-detects the Saga Pro native config HID endpoint.
- Shows battery percentage from the confirmed `50 02 -> 51 02` battery query.
- Saves four-stage DPI tables to the mouse using the native Saga `0x32` DPI table report.
- Applies live RGB and brightness using native Saga `0x44`/`0x40` reports.
- Saves RGB color and brightness to onboard memory using the confirmed `rgb-only` profile sequence.
- Stores local app profiles in `~/.config/hyperx-saga-control/profiles.json`.
- Installs a KDE autostart entry so the app starts minimized in the tray.

## Known devices

| Mode | USB ID | Typical native config node |
| --- | --- | --- |
| Wired USB | `03f0:04bf` | `/dev/hidraw2` |
| 2.4 GHz wireless | `03f0:06bf` | `/dev/hidraw3` |

The app scans `/dev/hidraw*` and looks for the native config descriptor, so the exact hidraw number does not need to stay fixed.

## Install on Fedora KDE

```bash
sudo dnf install python3-pyside6
unzip hyperx-saga-control.zip
cd hyperx-saga-control
./install.sh
```

Then unplug/replug the mouse or dongle and run:

```bash
~/.local/bin/hyperx-saga-control
```

## Install on Bazzite / Fedora Atomic Desktop

Bazzite uses an atomic base image. If `python3-pyside6` is not already installed, layer it and reboot:

```bash
rpm-ostree install python3-pyside6
systemctl reboot
```

Then install the app:

```bash
unzip hyperx-saga-control.zip
cd hyperx-saga-control
./install.sh
```

## Udev access

The installer places this rule in `/etc/udev/rules.d/99-hyperx-saga-pro.rules`:

```udev
SUBSYSTEM=="hidraw", ATTRS{idVendor}=="03f0", ATTRS{idProduct}=="04bf", TAG+="uaccess", MODE="0660"
SUBSYSTEM=="hidraw", ATTRS{idVendor}=="03f0", ATTRS{idProduct}=="06bf", TAG+="uaccess", MODE="0660"
```

After installing the udev rule, unplug/replug the mouse or dongle.

## Usage

Open the app from the application menu or run:

```bash
hyperx-saga-control
```

The main window has these tabs:

- **Status**: battery percentage and wired/wireless mode.
- **RGB Profile**: color picker, brightness, live apply, onboard save.
- **DPI Profile**: four DPI stages and active stage, written via the native `0x32` table.
- **Local Profiles**: local named profiles for color/brightness/DPI combinations.
- **Log**: raw operation notes and errors.

Closing the window hides it to the system tray. Use the tray icon menu to reopen it, refresh battery, or apply the selected local profile.

## What is intentionally not included yet

Wireless 4 kHz polling control is not implemented yet. Once the wireless 1000 Hz versus 4000 Hz NGENUITY captures are decoded, the polling tab/commands can be added cleanly.

## Safety notes

- RGB onboard save writes profile memory.
- DPI save writes the native DPI table.
- The app does **not** send unknown polling commands.
- The app does **not** use the old Pulsefire Dart `de ff` save packet.

## Uninstall

```bash
./uninstall.sh
```

To remove the udev rule too:

```bash
sudo rm /etc/udev/rules.d/99-hyperx-saga-pro.rules
sudo udevadm control --reload-rules
```

## v21 detection fix

This build adds a more robust native-config detector for the observed Saga Pro USB interface layout:

- wired 03f0:04bf: interface 1.2
- wireless 03f0:06bf: interface 1.3

It also includes `scripts/diagnose-devices.py` for debugging hidraw detection.


## v23 permission fix

If the application detects the mouse but prints `Permission denied`, install the stronger hidraw rule:

```bash
cd ~/Applications/hyperx-saga-control
./scripts/install-hidraw-permissions.sh
```

Then unplug/replug the mouse cable or 2.4 GHz dongle. The rule is limited to HyperX Pulsefire Saga Pro wired `03f0:04bf` and wireless `03f0:06bf` devices.
